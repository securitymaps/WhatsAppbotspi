# WhatsAppApiBot

Proyecto listo para desplegar en Firebase Hosting.

## Comandos
```bash
npm install
npm run build
```
La carpeta `/dist` será publicada automáticamente.
