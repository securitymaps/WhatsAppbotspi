import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState, useEffect } from "react";
import AuthPage from "@/pages/auth";
import DashboardPage from "@/pages/dashboard";
import CRMPage from "@/pages/crm";
import ChatbotsPage from "@/pages/chatbots";
import WebhooksPage from "@/pages/webhooks";
import NotFound from "@/pages/not-found";

function Router() {
  const [user, setUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing authentication
    const storedToken = localStorage.getItem("auth_token");
    const storedUser = localStorage.getItem("user");
    
    if (storedToken && storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setToken(storedToken);
        setUser(parsedUser);
      } catch (error) {
        console.error("Error parsing stored user:", error);
        localStorage.removeItem("auth_token");
        localStorage.removeItem("user");
      }
    }
    
    setLoading(false);
  }, []);

  const handleAuthSuccess = (authenticatedUser: any, authToken: string) => {
    setUser(authenticatedUser);
    setToken(authToken);
  };

  const handleLogout = () => {
    localStorage.removeItem("auth_token");
    localStorage.removeItem("user");
    setUser(null);
    setToken(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Cargando...</p>
        </div>
      </div>
    );
  }

  if (!user || !token) {
    return <AuthPage onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <Switch>
      <Route path="/" component={() => 
        user.role === "ceo" ? <DashboardPage user={user} /> : <CRMPage user={user} token={token} />
      } />
      <Route path="/auth" component={() => <AuthPage onAuthSuccess={handleAuthSuccess} />} />
      <Route path="/dashboard" component={() => <DashboardPage user={user} />} />
      <Route path="/crm" component={() => <CRMPage user={user} token={token} />} />
      <Route path="/chatbots" component={() => <ChatbotsPage user={user} />} />
      <Route path="/webhooks" component={() => <WebhooksPage user={user} />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
