import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  MessageCircle, Users, Bot, TrendingUp, Crown, 
  MoreHorizontal, Edit, BarChart, Calendar 
} from "lucide-react";

interface CEODashboardProps {
  user: any;
}

export function CEODashboard({ user }: CEODashboardProps) {
  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
    enabled: user?.role === "ceo",
  });

  const metrics = [
    {
      title: "Usuarios Activos",
      value: stats?.activeUsers || 2847,
      change: "+12% vs mes anterior",
      icon: Users,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
    },
    {
      title: "Mensajes Enviados",
      value: stats?.messagesSent || 18293,
      change: "+8% esta semana",
      icon: MessageCircle,
      bgColor: "bg-blue-100",
      iconColor: "text-blue-600",
    },
    {
      title: "Bots Activos",
      value: stats?.activeBots || 12,
      change: "3 empresas premium",
      icon: Bot,
      bgColor: "bg-purple-100",
      iconColor: "text-purple-600",
    },
    {
      title: "Conversiones",
      value: `${stats?.conversions || 94.2}%`,
      change: "+2.1% eficiencia",
      icon: TrendingUp,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
    },
  ];

  const mockUsers = [
    {
      id: "1",
      name: "Juan Pérez",
      email: "juan@empresa.com",
      status: "Activo",
      statusColor: "bg-green-100 text-green-800",
      avatar: "JD",
      avatarColor: "from-blue-500 to-purple-600",
    },
    {
      id: "2",
      name: "María García",
      email: "maria@startup.co",
      status: "Premium",
      statusColor: "bg-yellow-100 text-yellow-800",
      avatar: "MG",
      avatarColor: "from-green-500 to-teal-600",
    },
  ];

  const mockBots = [
    {
      id: "1",
      name: "Bot Atención Premium",
      company: "Empresa Premium SAS",
      messages: 1247,
      responseTime: "0.8s",
      satisfaction: "94%",
      status: "Activo",
    },
    {
      id: "2",
      name: "Bot E-commerce Avanzado",
      company: "TechStore Online",
      messages: 892,
      responseTime: "1.2s",
      satisfaction: "91%",
      status: "Activo",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Header */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="h-8 w-8 bg-green-500 rounded-lg flex items-center justify-center mr-3">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-gray-900">WhatsApp API - Panel CEO</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">CEO Dashboard</span>
              <div className="h-8 w-8 bg-amber-100 rounded-full flex items-center justify-center">
                <Crown className="h-4 w-4 text-amber-600" />
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Dashboard Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, index) => (
            <Card key={index} className="border border-gray-100">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className={`h-12 w-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                    <metric.icon className={`h-6 w-6 ${metric.iconColor}`} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                    <p className="text-sm text-green-600">{metric.change}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Management Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* User Management */}
          <Card className="border border-gray-100">
            <CardHeader className="border-b border-gray-100">
              <CardTitle className="text-lg font-semibold text-gray-900">Gestión de Usuarios</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {mockUsers.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className={`h-10 w-10 bg-gradient-to-r ${user.avatarColor} rounded-full flex items-center justify-center text-white font-medium`}>
                        {user.avatar}
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 text-xs font-medium ${user.statusColor} rounded-full`}>
                        {user.status}
                      </span>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              <Button variant="outline" className="mt-4 w-full">
                Ver Todos los Usuarios
              </Button>
            </CardContent>
          </Card>

          {/* Bot Management */}
          <Card className="border border-gray-100">
            <CardHeader className="border-b border-gray-100">
              <CardTitle className="text-lg font-semibold text-gray-900">Gestión de Chatbots</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {mockBots.map((bot) => (
                  <div key={bot.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <div className="h-8 w-8 bg-green-500 rounded-lg flex items-center justify-center">
                          <Bot className="h-4 w-4 text-white" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">{bot.name}</p>
                          <p className="text-xs text-gray-500">{bot.company}</p>
                        </div>
                      </div>
                      <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                        {bot.status}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-lg font-semibold text-gray-900">{bot.messages}</p>
                        <p className="text-xs text-gray-500">Mensajes</p>
                      </div>
                      <div>
                        <p className="text-lg font-semibold text-gray-900">{bot.responseTime}</p>
                        <p className="text-xs text-gray-500">Respuesta</p>
                      </div>
                      <div>
                        <p className="text-lg font-semibold text-gray-900">{bot.satisfaction}</p>
                        <p className="text-xs text-gray-500">Satisfacción</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <Button className="mt-4 w-full bg-green-500 hover:bg-green-600">
                Crear Nuevo Bot
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Section */}
        <Card className="mt-8 border border-gray-100">
          <CardHeader className="border-b border-gray-100">
            <CardTitle className="text-lg font-semibold text-gray-900">Análisis de Rendimiento</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="h-64 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Gráfico de Análisis de Rendimiento</p>
                <p className="text-sm text-gray-500">Implementar con librería de gráficos</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
