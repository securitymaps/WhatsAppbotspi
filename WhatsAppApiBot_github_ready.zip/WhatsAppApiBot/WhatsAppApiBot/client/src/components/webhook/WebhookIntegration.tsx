import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { 
  Copy, CheckCircle, ExternalLink, Send, Globe,
  Code, Settings, Key, Webhook, Zap
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface WebhookIntegrationProps {
  user: any;
}

export function WebhookIntegration({ user }: WebhookIntegrationProps) {
  const [testData, setTestData] = useState({
    phoneNumber: "",
    message: "",
  });
  const { toast } = useToast();

  const webhookConfig = {
    url: process.env.WEBHOOK_URL || "https://whatsapp-4t10.onrender.com/webhook",
    verifyToken: process.env.VERIFY_TOKEN || "mi_token_de_verificacion",
    appId: process.env.APP_ID || "1711244566103711",
    accountSid: process.env.ACCOUNT_SID || "190200340839409",
    phoneNumberId: process.env.PHONE_NUMBER_ID || "138339792706281",
  };

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "¡Copiado!",
        description: `${label} copiado al portapapeles`,
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo copiar al portapapeles",
      });
    }
  };

  const handleTestMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testData.phoneNumber || !testData.message) {
      toast({
        variant: "destructive",
        title: "Campos requeridos",
        description: "Por favor completa todos los campos",
      });
      return;
    }

    // Here you would implement the actual test message sending
    toast({
      title: "Mensaje de prueba enviado",
      description: `Mensaje enviado a ${testData.phoneNumber}`,
    });
    
    setTestData({ phoneNumber: "", message: "" });
  };

  const integrationSteps = [
    {
      number: 1,
      title: "Configurar Webhook en Meta Developer",
      description: "Ve a tu aplicación en Meta for Developers y configura el webhook con la URL proporcionada.",
      color: "bg-blue-100 text-blue-600",
    },
    {
      number: 2,
      title: "Verificar Token",
      description: "Usa el token de verificación para completar la configuración del webhook.",
      color: "bg-green-100 text-green-600",
    },
    {
      number: 3,
      title: "Probar Integración",
      description: "Envía un mensaje de prueba para verificar que todo funciona correctamente.",
      color: "bg-purple-100 text-purple-600",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card className="overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
            <div className="flex items-center space-x-3">
              <Webhook className="h-6 w-6" />
              <div>
                <CardTitle className="text-lg">Configuración de Webhook Automático</CardTitle>
                <p className="text-blue-100 text-sm mt-1">Integra tu aplicación con WhatsApp Business API</p>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            {/* Webhook Configuration */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="text-md font-semibold text-gray-900 mb-4 flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Configuración Automática
                </h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">URL del Webhook</Label>
                    <div className="flex mt-1">
                      <Input
                        type="text"
                        readOnly
                        value={webhookConfig.url}
                        className="bg-gray-50 text-gray-900 flex-1 rounded-r-none"
                      />
                      <Button 
                        onClick={() => copyToClipboard(webhookConfig.url, "URL del Webhook")}
                        className="bg-blue-500 hover:bg-blue-600 rounded-l-none"
                        size="icon"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Token de Verificación</Label>
                    <div className="flex mt-1">
                      <Input
                        type="text"
                        readOnly
                        value={webhookConfig.verifyToken}
                        className="bg-gray-50 text-gray-900 flex-1 rounded-r-none"
                      />
                      <Button 
                        onClick={() => copyToClipboard(webhookConfig.verifyToken, "Token de Verificación")}
                        className="bg-green-500 hover:bg-green-600 rounded-l-none"
                        size="icon"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <Alert className="border-green-200 bg-green-50">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-700">
                      <strong>Webhook Verificado</strong>
                      <br />
                      Tu webhook está configurado y funcionando correctamente.
                    </AlertDescription>
                  </Alert>
                </div>
              </div>

              <div>
                <h3 className="text-md font-semibold text-gray-900 mb-4 flex items-center">
                  <Key className="h-5 w-5 mr-2" />
                  Credenciales de Aplicación
                </h3>
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">App ID</Label>
                    <div className="flex mt-1">
                      <Input
                        type="text"
                        readOnly
                        value={webhookConfig.appId}
                        className="bg-gray-50 text-gray-900 flex-1 rounded-r-none"
                      />
                      <Button 
                        onClick={() => copyToClipboard(webhookConfig.appId, "App ID")}
                        className="bg-purple-500 hover:bg-purple-600 rounded-l-none"
                        size="icon"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Account SID</Label>
                    <div className="flex mt-1">
                      <Input
                        type="text"
                        readOnly
                        value={webhookConfig.accountSid}
                        className="bg-gray-50 text-gray-900 flex-1 rounded-r-none"
                      />
                      <Button 
                        onClick={() => copyToClipboard(webhookConfig.accountSid, "Account SID")}
                        className="bg-yellow-500 hover:bg-yellow-600 rounded-l-none"
                        size="icon"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">Phone Number ID</Label>
                    <div className="flex mt-1">
                      <Input
                        type="text"
                        readOnly
                        value={webhookConfig.phoneNumberId}
                        className="bg-gray-50 text-gray-900 flex-1 rounded-r-none"
                      />
                      <Button 
                        onClick={() => copyToClipboard(webhookConfig.phoneNumberId, "Phone Number ID")}
                        className="bg-teal-500 hover:bg-teal-600 rounded-l-none"
                        size="icon"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Integration Steps */}
            <div className="mt-8">
              <h3 className="text-md font-semibold text-gray-900 mb-4 flex items-center">
                <Code className="h-5 w-5 mr-2" />
                Pasos de Integración
              </h3>
              <div className="space-y-4">
                {integrationSteps.map((step) => (
                  <div key={step.number} className="flex items-start space-x-3">
                    <div className={`h-8 w-8 ${step.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <span className="text-sm font-medium">{step.number}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{step.title}</p>
                      <p className="text-sm text-gray-600 mt-1">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="p-4 border-2 border-dashed border-gray-200 hover:border-blue-300 transition-colors">
                <div className="text-center">
                  <Globe className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-900 mb-1">Meta for Developers</h4>
                  <p className="text-sm text-gray-600 mb-3">Configurar webhook en Meta</p>
                  <Button variant="outline" size="sm" className="w-full">
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Abrir Portal
                  </Button>
                </div>
              </Card>

              <Card className="p-4 border-2 border-dashed border-gray-200 hover:border-green-300 transition-colors">
                <div className="text-center">
                  <Zap className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-900 mb-1">WhatsApp Business API</h4>
                  <p className="text-sm text-gray-600 mb-3">Documentación oficial</p>
                  <Button variant="outline" size="sm" className="w-full">
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Ver Docs
                  </Button>
                </div>
              </Card>

              <Card className="p-4 border-2 border-dashed border-gray-200 hover:border-purple-300 transition-colors">
                <div className="text-center">
                  <Settings className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-900 mb-1">Configuración Avanzada</h4>
                  <p className="text-sm text-gray-600 mb-3">Personalizar webhook</p>
                  <Button variant="outline" size="sm" className="w-full">
                    <Settings className="h-4 w-4 mr-1" />
                    Configurar
                  </Button>
                </div>
              </Card>
            </div>

            {/* Test Integration */}
            <div className="mt-8 p-6 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                <Send className="h-5 w-5 mr-2" />
                Probar Integración
              </h4>
              <form onSubmit={handleTestMessage} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="test-phone">Número de teléfono</Label>
                    <Input
                      id="test-phone"
                      type="tel"
                      placeholder="+57 123 456 7890"
                      value={testData.phoneNumber}
                      onChange={(e) => setTestData({ ...testData, phoneNumber: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="test-message">Mensaje de prueba</Label>
                    <Input
                      id="test-message"
                      type="text"
                      placeholder="¡Hola! Este es un mensaje de prueba"
                      value={testData.message}
                      onChange={(e) => setTestData({ ...testData, message: e.target.value })}
                      className="mt-1"
                    />
                  </div>
                </div>
                <Button type="submit" className="bg-green-500 hover:bg-green-600">
                  <Send className="h-4 w-4 mr-2" />
                  Enviar Mensaje de Prueba
                </Button>
              </form>
            </div>

            {/* Status Indicators */}
            <div className="mt-8">
              <h4 className="font-medium text-gray-900 mb-3">Estado de la Integración</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-green-800">Webhook Activo</p>
                    <p className="text-xs text-green-600">Recibiendo eventos</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-green-800">API Conectada</p>
                    <p className="text-xs text-green-600">Enviando mensajes</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-green-800">Token Válido</p>
                    <p className="text-xs text-green-600">Autenticación exitosa</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
