import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MessageCircle, User, UserX, Send, Shield, CheckCircle } from "lucide-react";
import { signInWithGoogle, signInWithFacebook, signInAnonymous, handleRedirectResult } from "@/lib/firebase";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AuthenticationSystemProps {
  onAuthSuccess: (user: any, token: string) => void;
}

export function AuthenticationSystem({ onAuthSuccess }: AuthenticationSystemProps) {
  const [authMode, setAuthMode] = useState<"regular" | "ceo">("regular");
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    phone: "",
    ceoEmail: "",
    ceoToken: "",
  });
  const { toast } = useToast();

  useEffect(() => {
    // Handle Firebase redirect result
    handleRedirectResult().then((result) => {
      if (result) {
        handleFirebaseAuth(result.user, result.provider);
      }
    }).catch((error) => {
      console.error("Firebase redirect error:", error);
      toast({
        variant: "destructive",
        title: "Authentication Error",
        description: "Failed to complete social login",
      });
    });
  }, []);

  const handleFirebaseAuth = async (user: any, provider: string) => {
    try {
      setLoading(true);
      const response = await apiRequest("POST", "/api/auth/firebase", {
        firebaseUid: user.uid,
        email: user.email,
        name: user.displayName,
        provider,
      });
      
      const data = await response.json();
      onAuthSuccess(data.user, data.token);
      
      toast({
        title: "¡Bienvenido!",
        description: `Autenticación exitosa con ${provider === 'google' ? 'Google' : 'Facebook'}`,
      });
    } catch (error) {
      console.error("Firebase auth error:", error);
      toast({
        variant: "destructive",
        title: "Error de Autenticación",
        description: "No se pudo completar la autenticación social",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
      toast({
        variant: "destructive",
        title: "Campos requeridos",
        description: "Por favor ingresa email y contraseña",
      });
      return;
    }

    try {
      setLoading(true);
      const response = await apiRequest("POST", "/api/auth/login", {
        email: formData.email,
        password: formData.password,
      });
      
      const data = await response.json();
      onAuthSuccess(data.user, data.token);
      
      toast({
        title: "¡Bienvenido!",
        description: "Inicio de sesión exitoso",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error de Autenticación",
        description: "Credenciales inválidas",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCEOLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.ceoEmail || !formData.ceoToken) {
      toast({
        variant: "destructive",
        title: "Campos requeridos",
        description: "Por favor ingresa email y token de verificación",
      });
      return;
    }

    try {
      setLoading(true);
      const response = await apiRequest("POST", "/api/auth/ceo-login", {
        email: formData.ceoEmail,
        token: formData.ceoToken,
      });
      
      const data = await response.json();
      onAuthSuccess(data.user, data.token);
      
      toast({
        title: "¡Bienvenido CEO!",
        description: "Acceso administrativo concedido",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error de Acceso",
        description: "Token de verificación inválido",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo iniciar autenticación con Google",
      });
    }
  };

  const handleFacebookLogin = async () => {
    try {
      await signInWithFacebook();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo iniciar autenticación con Facebook",
      });
    }
  };

  const handleAnonymousLogin = async () => {
    try {
      setLoading(true);
      const user = await signInAnonymous();
      
      const response = await apiRequest("POST", "/api/auth/register", {
        firebaseUid: user.uid,
        authProvider: "anonymous",
      });
      
      const data = await response.json();
      onAuthSuccess(data.user, data.token);
      
      toast({
        title: "Acceso Anónimo",
        description: "Sesión iniciada como invitado",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo iniciar sesión anónima",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-white flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8">
        {/* Logo and Header */}
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-green-500 rounded-xl flex items-center justify-center mb-4">
            <MessageCircle className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900">WhatsApp API</h2>
          <p className="mt-2 text-sm text-gray-600">Plataforma Profesional de Comunicación Empresarial</p>
        </div>

        {/* Authentication Methods Card */}
        <Card className="shadow-xl">
          <CardContent className="p-8 space-y-6">
            {/* Login Type Toggle */}
            <div className="flex space-x-2 bg-gray-100 p-1 rounded-lg">
              <Button
                variant={authMode === "regular" ? "default" : "ghost"}
                size="sm"
                className="flex-1"
                onClick={() => setAuthMode("regular")}
              >
                Usuario Regular
              </Button>
              <Button
                variant={authMode === "ceo" ? "default" : "ghost"}
                size="sm"
                className="flex-1"
                onClick={() => setAuthMode("ceo")}
              >
                CEO/Admin
              </Button>
            </div>

            {/* Regular User Authentication */}
            {authMode === "regular" && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Iniciar Sesión</h3>
                
                {/* Social Authentication Buttons */}
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    onClick={handleGoogleLogin}
                    disabled={loading}
                    className="w-full"
                  >
                    <img 
                      src="https://developers.google.com/identity/images/g-logo.png" 
                      alt="Google" 
                      className="w-5 h-5 mr-2" 
                    />
                    Google
                  </Button>
                  <Button
                    variant="outline"
                    onClick={handleFacebookLogin}
                    disabled={loading}
                    className="w-full"
                  >
                    <div className="w-5 h-5 mr-2 bg-blue-600 rounded flex items-center justify-center text-white text-xs font-bold">
                      f
                    </div>
                    Facebook
                  </Button>
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-300"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white text-gray-500">o continúa con</span>
                  </div>
                </div>

                {/* Email/Password Form */}
                <form onSubmit={handleEmailLogin} className="space-y-4">
                  <div>
                    <Label htmlFor="email">Correo Electrónico</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="mt-1"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="password">Contraseña</Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="mt-1"
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full bg-green-500 hover:bg-green-600" disabled={loading}>
                    {loading ? "Iniciando..." : "Iniciar Sesión"}
                  </Button>
                </form>

                {/* Phone Authentication */}
                <div className="space-y-4">
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-gray-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-2 bg-white text-gray-500">Autenticación por SMS</span>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Input
                      type="tel"
                      placeholder="+57 123 456 7890"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="flex-1"
                    />
                    <Button size="icon" variant="outline">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* reCAPTCHA */}
                <div className="flex items-center space-x-2">
                  <Checkbox id="recaptcha" />
                  <Label htmlFor="recaptcha" className="text-sm">No soy un robot (reCAPTCHA)</Label>
                </div>

                {/* Anonymous Login */}
                <Button
                  variant="outline"
                  onClick={handleAnonymousLogin}
                  disabled={loading}
                  className="w-full"
                >
                  <UserX className="h-4 w-4 mr-2" />
                  Continuar como Invitado
                </Button>
              </div>
            )}

            {/* CEO Authentication */}
            {authMode === "ceo" && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Acceso CEO/Administrador</h3>
                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Acceso Restringido</strong>
                    <br />
                    Se requiere token de verificación para acceso administrativo.
                  </AlertDescription>
                </Alert>
                
                <form onSubmit={handleCEOLogin} className="space-y-4">
                  <div>
                    <Label htmlFor="ceo-email">Email CEO</Label>
                    <Input
                      id="ceo-email"
                      type="email"
                      value={formData.ceoEmail}
                      onChange={(e) => setFormData({ ...formData, ceoEmail: e.target.value })}
                      className="mt-1"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="ceo-token">Token de Verificación</Label>
                    <Input
                      id="ceo-token"
                      type="password"
                      value={formData.ceoToken}
                      onChange={(e) => setFormData({ ...formData, ceoToken: e.target.value })}
                      className="mt-1"
                      required
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-amber-600 hover:bg-amber-700" 
                    disabled={loading}
                  >
                    {loading ? "Verificando..." : "Acceder como CEO"}
                  </Button>
                </form>
              </div>
            )}

            {/* Developer Integration Section */}
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="text-sm font-medium text-blue-900 mb-2">Integración para Desarrolladores</h4>
              <p className="text-xs text-blue-700 mb-3">Configura tu aplicación con las credenciales proporcionadas</p>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-600">App ID:</span>
                  <code className="text-blue-600">1711244566103711</code>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Account SID:</span>
                  <code className="text-blue-600">190200340839409</code>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Webhook URL:</span>
                  <code className="text-blue-600 truncate">whatsapp-4t10.onrender.com</code>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
