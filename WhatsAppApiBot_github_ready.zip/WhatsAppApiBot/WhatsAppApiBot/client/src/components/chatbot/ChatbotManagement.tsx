import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Bot, Building2, ShoppingCart, HeartPulse, GraduationCap, 
  Landmark, Headphones, Edit, BarChart, Calendar, Plus,
  Sparkles, Clock, Users, TrendingUp
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface BotTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  template: "corporate" | "ecommerce" | "healthcare" | "education" | "finance" | "support";
  icon: React.ComponentType<any>;
  color: string;
  features: string[];
}

interface Chatbot {
  id: string;
  name: string;
  description: string;
  template: string;
  isActive: boolean;
  createdAt: string;
  config: any;
  analytics?: {
    totalInteractions: number;
    averageResponseTime: number;
    escalationRate: number;
    satisfactionScore: number;
  };
}

interface ChatbotManagementProps {
  user: any;
}

export function ChatbotManagement({ user }: ChatbotManagementProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    template: "",
  });
  const { toast } = useToast();

  const botTemplates: BotTemplate[] = [
    {
      id: "corporate",
      name: "Bot Corporativo",
      category: "Empresas Fortune 500",
      description: "Bot profesional para grandes corporaciones con respuestas automatizadas, escalamiento a agentes humanos y análisis de sentimiento.",
      template: "corporate",
      icon: Building2,
      color: "from-blue-500 to-blue-600",
      features: ["IA Avanzada", "24/7"],
    },
    {
      id: "ecommerce",
      name: "Bot E-commerce",
      category: "Retail & Ventas",
      description: "Bot especializado en ventas online con catálogo integrado, procesamiento de órdenes y seguimiento de envíos automatizado.",
      template: "ecommerce",
      icon: ShoppingCart,
      color: "from-green-500 to-green-600",
      features: ["Pagos", "Catálogo"],
    },
    {
      id: "healthcare",
      name: "Bot Salud",
      category: "Sector Médico",
      description: "Bot médico con agendamiento de citas, recordatorios de medicamentos y triaje inicial para instituciones de salud.",
      template: "healthcare",
      icon: HeartPulse,
      color: "from-red-500 to-red-600",
      features: ["HIPAA", "Citas"],
    },
    {
      id: "education",
      name: "Bot Educativo",
      category: "Universidades",
      description: "Bot para instituciones educativas con información académica, matrículas, calificaciones y soporte estudiantil.",
      template: "education",
      icon: GraduationCap,
      color: "from-yellow-500 to-yellow-600",
      features: ["Académico", "Estudiantil"],
    },
    {
      id: "finance",
      name: "Bot Financiero",
      category: "Bancos & Fintech",
      description: "Bot bancario con consultas de saldo, transferencias, productos financieros y asistencia de inversiones con alta seguridad.",
      template: "finance",
      icon: Landmark,
      color: "from-indigo-500 to-indigo-600",
      features: ["Seguro", "Finanzas"],
    },
    {
      id: "support",
      name: "Bot Soporte IT",
      category: "Tecnología",
      description: "Bot técnico especializado en soporte IT, resolución de incidencias, gestión de tickets y mantenimiento preventivo.",
      template: "support",
      icon: Headphones,
      color: "from-teal-500 to-teal-600",
      features: ["IT Support", "Tickets"],
    },
  ];

  // Fetch user's chatbots
  const { data: chatbots = [], isLoading: loadingBots } = useQuery({
    queryKey: ["/api/chatbots"],
  });

  // Create chatbot mutation
  const createBotMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/chatbots", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chatbots"] });
      setShowCreateForm(false);
      setFormData({ name: "", description: "", template: "" });
      setSelectedTemplate("");
      toast({
        title: "¡Éxito!",
        description: "Chatbot creado exitosamente",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo crear el chatbot",
      });
    },
  });

  const handleCreateBot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.template) {
      toast({
        variant: "destructive",
        title: "Campos requeridos",
        description: "Por favor completa todos los campos requeridos",
      });
      return;
    }

    createBotMutation.mutate({
      ...formData,
      isActive: true,
      config: {
        template: formData.template,
        autoResponse: true,
        escalationEnabled: true,
      },
    });
  };

  const handleUseTemplate = (template: BotTemplate) => {
    setSelectedTemplate(template.id);
    setFormData({
      name: template.name,
      description: template.description,
      template: template.template,
    });
    setShowCreateForm(true);
  };

  const getFeatureBadgeColor = (feature: string) => {
    const colors: { [key: string]: string } = {
      "IA Avanzada": "bg-blue-100 text-blue-800",
      "24/7": "bg-green-100 text-green-800",
      "Pagos": "bg-green-100 text-green-800",
      "Catálogo": "bg-purple-100 text-purple-800",
      "HIPAA": "bg-red-100 text-red-800",
      "Citas": "bg-blue-100 text-blue-800",
      "Académico": "bg-yellow-100 text-yellow-800",
      "Estudiantil": "bg-indigo-100 text-indigo-800",
      "Seguro": "bg-indigo-100 text-indigo-800",
      "Finanzas": "bg-green-100 text-green-800",
      "IT Support": "bg-teal-100 text-teal-800",
      "Tickets": "bg-gray-100 text-gray-800",
    };
    return colors[feature] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="h-8 w-8 bg-purple-500 rounded-lg flex items-center justify-center mr-3">
                <Bot className="h-5 w-5 text-white" />
              </div>
              <h1 className="text-xl font-semibold text-gray-900">Gestión de Chatbots Profesionales</h1>
            </div>
            <Button 
              onClick={() => setShowCreateForm(true)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Crear Nuevo Bot
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Create Bot Form */}
        {showCreateForm && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Crear Nuevo Chatbot</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateBot} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="bot-name">Nombre del Bot</Label>
                    <Input
                      id="bot-name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Mi Bot de Atención"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="bot-template">Plantilla</Label>
                    <Select
                      value={formData.template}
                      onValueChange={(value) => setFormData({ ...formData, template: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona una plantilla" />
                      </SelectTrigger>
                      <SelectContent>
                        {botTemplates.map((template) => (
                          <SelectItem key={template.id} value={template.template}>
                            {template.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="bot-description">Descripción</Label>
                  <Textarea
                    id="bot-description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe la función de tu chatbot..."
                    rows={3}
                  />
                </div>
                <div className="flex space-x-2">
                  <Button type="submit" disabled={createBotMutation.isPending}>
                    {createBotMutation.isPending ? "Creando..." : "Crear Bot"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setShowCreateForm(false);
                      setFormData({ name: "", description: "", template: "" });
                      setSelectedTemplate("");
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Bot Templates for Important Businesses */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Plantillas para Empresas Importantes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {botTemplates.map((template) => (
              <Card 
                key={template.id} 
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleUseTemplate(template)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`h-12 w-12 bg-gradient-to-r ${template.color} rounded-xl flex items-center justify-center`}>
                      <template.icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="ml-4">
                      <h3 className="font-semibold text-gray-900">{template.name}</h3>
                      <p className="text-sm text-gray-500">{template.category}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{template.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      {template.features.map((feature) => (
                        <Badge 
                          key={feature}
                          className={getFeatureBadgeColor(feature)}
                        >
                          {feature}
                        </Badge>
                      ))}
                    </div>
                    <Button 
                      variant="link" 
                      size="sm"
                      className="text-blue-600 hover:text-blue-700 p-0"
                    >
                      Usar Plantilla
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Active Bots Management */}
        <Card>
          <CardHeader>
            <CardTitle>Bots Activos en Producción</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingBots ? (
              <div className="text-center py-8 text-gray-500">Cargando chatbots...</div>
            ) : chatbots.length === 0 ? (
              <div className="text-center py-8">
                <Bot className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No tienes chatbots</h3>
                <p className="text-gray-500 mb-4">Crea tu primer chatbot usando una de las plantillas profesionales</p>
                <Button onClick={() => setShowCreateForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Crear Primer Bot
                </Button>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {chatbots.map((chatbot: Chatbot) => (
                  <div key={chatbot.id} className="py-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="h-12 w-12 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                          <Bot className="h-6 w-6 text-white" />
                        </div>
                        <div className="ml-4">
                          <h4 className="font-semibold text-gray-900">{chatbot.name}</h4>
                          <p className="text-sm text-gray-600">{chatbot.description || "Sin descripción"}</p>
                          <div className="flex items-center space-x-4 mt-1">
                            <span className="flex items-center text-sm text-gray-500">
                              <Calendar className="h-4 w-4 mr-1" />
                              Creado: {format(new Date(chatbot.createdAt), "dd MMM yyyy")}
                            </span>
                            <Badge className={chatbot.isActive ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                              {chatbot.isActive ? "Activo" : "Inactivo"}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="text-lg font-semibold text-gray-900">
                            {chatbot.analytics?.totalInteractions || 0}
                          </p>
                          <p className="text-sm text-gray-500">Interacciones</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-semibold text-green-600">
                            {chatbot.analytics?.satisfactionScore || 0}%
                          </p>
                          <p className="text-sm text-gray-500">Satisfacción</p>
                        </div>
                        <Button variant="ghost" size="icon">
                          <Edit className="h-5 w-5" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <BarChart className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Bot Performance Metrics */}
                    <div className="mt-4 grid grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-center mb-1">
                          <Clock className="h-4 w-4 text-gray-600 mr-1" />
                        </div>
                        <p className="text-lg font-semibold text-gray-900">
                          {chatbot.analytics?.averageResponseTime || 0}ms
                        </p>
                        <p className="text-xs text-gray-500">Tiempo Respuesta</p>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-center mb-1">
                          <Sparkles className="h-4 w-4 text-gray-600 mr-1" />
                        </div>
                        <p className="text-lg font-semibold text-gray-900">
                          {100 - (chatbot.analytics?.escalationRate || 0)}%
                        </p>
                        <p className="text-xs text-gray-500">Resolución</p>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-center mb-1">
                          <Users className="h-4 w-4 text-gray-600 mr-1" />
                        </div>
                        <p className="text-lg font-semibold text-gray-900">
                          {chatbot.analytics?.escalationRate || 0}%
                        </p>
                        <p className="text-xs text-gray-500">Escalado</p>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-center mb-1">
                          <TrendingUp className="h-4 w-4 text-gray-600 mr-1" />
                        </div>
                        <p className="text-lg font-semibold text-gray-900">99.9%</p>
                        <p className="text-xs text-gray-500">Disponibilidad</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
