import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  MessageCircle, Search, Settings, UserPlus, Radio, LayoutTemplate,
  Phone, Video, Info, MoreVertical, Paperclip, Smile, Send,
  CheckCheck, Ban, Archive, Download, MapPin, Building, Mail
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useWebSocket } from "@/lib/websocket";
import { useToast } from "@/hooks/use-toast";
import { format, isToday, isYesterday } from "date-fns";

interface Contact {
  id: string;
  name: string;
  phone: string;
  email?: string;
  company?: string;
  avatar?: string;
  lastMessageAt?: string;
  unreadCount?: number;
  isArchived: boolean;
}

interface Message {
  id: string;
  content: string;
  direction: "inbound" | "outbound";
  type: "text" | "image" | "audio" | "video" | "document";
  status: "sent" | "delivered" | "read" | "failed";
  isFromBot: boolean;
  timestamp: string;
}

interface Conversation {
  id: string;
  contactId: string;
  lastMessageAt?: string;
  unreadCount: number;
}

interface WhatsAppCRMProps {
  user: any;
  token: string;
}

export function WhatsAppCRM({ user, token }: WhatsAppCRMProps) {
  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [messageInput, setMessageInput] = useState("");
  const [filterType, setFilterType] = useState<"all" | "unread" | "archived">("all");
  const { toast } = useToast();
  
  const { lastMessage, sendMessage } = useWebSocket(token);

  // Fetch contacts
  const { data: contacts = [], isLoading: loadingContacts } = useQuery({
    queryKey: ["/api/contacts"],
  });

  // Fetch conversations
  const { data: conversations = [] } = useQuery({
    queryKey: ["/api/conversations"],
  });

  // Fetch messages for selected contact
  const selectedConversation = conversations.find(
    (conv: Conversation) => conv.contactId === selectedContactId
  );

  const { data: messages = [], isLoading: loadingMessages } = useQuery({
    queryKey: ["/api/conversations", selectedConversation?.id, "messages"],
    enabled: !!selectedConversation?.id,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { conversationId: string; contactId: string; content: string }) => {
      const response = await apiRequest("POST", "/api/messages", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations", selectedConversation?.id, "messages"] });
      setMessageInput("");
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo enviar el mensaje",
      });
    },
  });

  // Handle WebSocket messages
  useEffect(() => {
    if (lastMessage?.type === "new_message") {
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      if (lastMessage.message.conversationId === selectedConversation?.id) {
        queryClient.invalidateQueries({ queryKey: ["/api/conversations", selectedConversation.id, "messages"] });
      }
    }
  }, [lastMessage, selectedConversation?.id]);

  const selectedContact = contacts.find((contact: Contact) => contact.id === selectedContactId);

  const filteredContacts = contacts.filter((contact: Contact) => {
    const matchesSearch = contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         contact.phone.includes(searchQuery);
    
    switch (filterType) {
      case "unread":
        return matchesSearch && (contact.unreadCount || 0) > 0;
      case "archived":
        return matchesSearch && contact.isArchived;
      default:
        return matchesSearch && !contact.isArchived;
    }
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !selectedConversation || !selectedContactId) return;

    sendMessageMutation.mutate({
      conversationId: selectedConversation.id,
      contactId: selectedContactId,
      content: messageInput,
    });

    // Also send via WebSocket for real-time update
    sendMessage({
      type: "send_message",
      conversationId: selectedConversation.id,
      contactId: selectedContactId,
      content: messageInput,
      userId: user.id,
    });
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    if (isToday(date)) {
      return format(date, "HH:mm");
    } else if (isYesterday(date)) {
      return "Ayer";
    } else {
      return format(date, "dd/MM");
    }
  };

  const getContactInitials = (name: string) => {
    return name
      .split(" ")
      .map(word => word[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="h-screen bg-gray-100 flex">
      {/* Contacts Sidebar */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
        {/* CRM Header */}
        <div className="p-4 border-b border-gray-200 bg-green-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="h-8 w-8 bg-white rounded-lg flex items-center justify-center mr-3">
                <MessageCircle className="h-5 w-5 text-green-500" />
              </div>
              <h2 className="text-white font-semibold">WhatsApp CRM</h2>
            </div>
            <Button variant="ghost" size="icon" className="text-white hover:text-green-100">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Input
              type="text"
              placeholder="Buscar contactos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          </div>
          <div className="flex space-x-2 mt-3">
            <Button
              variant={filterType === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("all")}
              className={filterType === "all" ? "bg-green-500 hover:bg-green-600" : ""}
            >
              Todos
            </Button>
            <Button
              variant={filterType === "unread" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("unread")}
              className={filterType === "unread" ? "bg-green-500 hover:bg-green-600" : ""}
            >
              No leídos
            </Button>
            <Button
              variant={filterType === "archived" ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType("archived")}
              className={filterType === "archived" ? "bg-green-500 hover:bg-green-600" : ""}
            >
              Archivados
            </Button>
          </div>
        </div>

        {/* Contacts List */}
        <ScrollArea className="flex-1">
          {loadingContacts ? (
            <div className="p-4 text-center text-gray-500">Cargando contactos...</div>
          ) : filteredContacts.length === 0 ? (
            <div className="p-4 text-center text-gray-500">No se encontraron contactos</div>
          ) : (
            filteredContacts.map((contact: Contact) => (
              <div
                key={contact.id}
                className={`p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors ${
                  selectedContactId === contact.id ? "bg-green-50 border-green-200" : ""
                }`}
                onClick={() => setSelectedContactId(contact.id)}
              >
                <div className="flex items-center">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-gradient-to-r from-green-500 to-green-600 text-white font-medium">
                      {getContactInitials(contact.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-gray-900">{contact.name}</p>
                      <span className="text-xs text-gray-500">
                        {contact.lastMessageAt && formatMessageTime(contact.lastMessageAt)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 truncate">
                      {contact.company || contact.phone}
                    </p>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-gray-500">{contact.phone}</span>
                      {(contact.unreadCount || 0) > 0 && (
                        <Badge className="bg-green-500 text-white">
                          {contact.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </ScrollArea>

        {/* Quick Actions */}
        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <div className="grid grid-cols-3 gap-2">
            <Button variant="ghost" size="sm" className="flex flex-col items-center p-2">
              <UserPlus className="h-5 w-5 text-gray-600 mb-1" />
              <span className="text-xs text-gray-600">Nuevo</span>
            </Button>
            <Button variant="ghost" size="sm" className="flex flex-col items-center p-2">
              <Radio className="h-5 w-5 text-gray-600 mb-1" />
              <span className="text-xs text-gray-600">Difusión</span>
            </Button>
            <Button variant="ghost" size="sm" className="flex flex-col items-center p-2">
              <LayoutTemplate className="h-5 w-5 text-gray-600 mb-1" />
              <span className="text-xs text-gray-600">Plantillas</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedContact ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 bg-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-gradient-to-r from-green-500 to-green-600 text-white font-medium">
                      {getContactInitials(selectedContact.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="ml-3">
                    <p className="font-medium text-gray-900">{selectedContact.name}</p>
                    <p className="text-sm text-gray-500">
                      En línea - último acceso hoy {formatMessageTime(selectedContact.lastMessageAt || new Date().toISOString())}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="icon">
                    <Phone className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Info className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Messages Area */}
            <ScrollArea className="flex-1 p-4 space-y-4 bg-chat-pattern">
              {loadingMessages ? (
                <div className="text-center text-gray-500">Cargando mensajes...</div>
              ) : messages.length === 0 ? (
                <div className="text-center text-gray-500">No hay mensajes</div>
              ) : (
                <div className="space-y-4">
                  {messages.map((message: Message) => (
                    <div
                      key={message.id}
                      className={`flex items-end space-x-2 ${
                        message.direction === "outbound" ? "justify-end" : ""
                      }`}
                    >
                      {message.direction === "inbound" && (
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs font-medium">
                            {getContactInitials(selectedContact.name)}
                          </AvatarFallback>
                        </Avatar>
                      )}
                      <div className="max-w-xs lg:max-w-md">
                        <div
                          className={`rounded-lg px-4 py-2 shadow-sm ${
                            message.direction === "outbound"
                              ? message.isFromBot
                                ? "bg-blue-100 border border-blue-200"
                                : "bg-green-500 text-white"
                              : "bg-white"
                          }`}
                        >
                          {message.isFromBot && (
                            <div className="flex items-center space-x-2 mb-2">
                              <MessageCircle className="h-4 w-4 text-blue-600" />
                              <span className="text-xs font-medium text-blue-700">Respuesta Automática</span>
                            </div>
                          )}
                          <p className={`text-sm ${message.direction === "outbound" && !message.isFromBot ? "text-white" : "text-gray-900"}`}>
                            {message.content}
                          </p>
                        </div>
                        <div className={`flex items-center mt-1 space-x-1 ${message.direction === "outbound" ? "justify-end" : ""}`}>
                          <p className="text-xs text-gray-500">{formatMessageTime(message.timestamp)}</p>
                          {message.direction === "outbound" && (
                            <CheckCheck 
                              className={`h-3 w-3 ${
                                message.status === "read" ? "text-blue-500" : "text-gray-400"
                              }`} 
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-200 bg-white">
              <form onSubmit={handleSendMessage} className="flex items-end space-x-2">
                <Button variant="ghost" size="icon" type="button">
                  <Paperclip className="h-5 w-5" />
                </Button>
                <div className="flex-1">
                  <div className="relative">
                    <Textarea
                      placeholder="Escribe un mensaje..."
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      rows={1}
                      className="resize-none pr-10"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage(e as any);
                        }
                      }}
                    />
                    <Button variant="ghost" size="icon" type="button" className="absolute right-2 top-1">
                      <Smile className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
                <Button 
                  type="submit" 
                  size="icon" 
                  className="bg-green-500 hover:bg-green-600"
                  disabled={!messageInput.trim() || sendMessageMutation.isPending}
                >
                  <Send className="h-5 w-5" />
                </Button>
              </form>
              
              {/* Quick Responses */}
              <div className="flex space-x-2 mt-3">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setMessageInput("¿En qué puedo ayudarte?")}
                >
                  ¿En qué puedo ayudarte?
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setMessageInput("Te contacto mañana")}
                >
                  Te contacto mañana
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setMessageInput("Información enviada")}
                >
                  Información enviada
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <MessageCircle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Selecciona una conversación</h3>
              <p className="text-gray-500">Elige un contacto para comenzar a chatear</p>
            </div>
          </div>
        )}
      </div>

      {/* Contact Info Sidebar */}
      {selectedContact && (
        <div className="w-80 bg-white border-l border-gray-200 hidden lg:block">
          <ScrollArea className="h-full">
            <div className="p-6">
              <div className="text-center mb-6">
                <Avatar className="h-20 w-20 mx-auto mb-4">
                  <AvatarFallback className="bg-gradient-to-r from-green-500 to-green-600 text-white font-medium text-xl">
                    {getContactInitials(selectedContact.name)}
                  </AvatarFallback>
                </Avatar>
                <h3 className="text-lg font-semibold text-gray-900">{selectedContact.name}</h3>
                <p className="text-sm text-gray-500">{selectedContact.phone}</p>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Información de Contacto</h4>
                  <div className="space-y-2">
                    {selectedContact.email && (
                      <div className="flex items-center space-x-2">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">{selectedContact.email}</span>
                      </div>
                    )}
                    {selectedContact.company && (
                      <div className="flex items-center space-x-2">
                        <Building className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">{selectedContact.company}</span>
                      </div>
                    )}
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">Ubicación no especificada</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Estadísticas</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <p className="text-lg font-semibold text-gray-900">
                        {messages.length}
                      </p>
                      <p className="text-xs text-gray-500">Mensajes</p>
                    </div>
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <p className="text-lg font-semibold text-gray-900">5m</p>
                      <p className="text-xs text-gray-500">Tiempo Resp.</p>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Acciones</h4>
                  <div className="space-y-2">
                    <Button variant="ghost" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50">
                      <Ban className="h-4 w-4 mr-2" />
                      Bloquear contacto
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      <Archive className="h-4 w-4 mr-2" />
                      Archivar conversación
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                      <Download className="h-4 w-4 mr-2" />
                      Exportar chat
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}
