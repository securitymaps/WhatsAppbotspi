import { WebhookIntegration } from "@/components/webhook/WebhookIntegration";

interface WebhooksPageProps {
  user: any;
}

export default function WebhooksPage({ user }: WebhooksPageProps) {
  return <WebhookIntegration user={user} />;
}
