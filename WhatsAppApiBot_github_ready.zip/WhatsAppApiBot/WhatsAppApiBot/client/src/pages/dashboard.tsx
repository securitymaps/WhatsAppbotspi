import { CEODashboard } from "@/components/dashboard/CEODashboard";

interface DashboardPageProps {
  user: any;
}

export default function DashboardPage({ user }: DashboardPageProps) {
  // Redirect non-CEO users
  if (user?.role !== "ceo") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Acceso Restringido</h1>
          <p className="text-gray-600">Esta página es solo para administradores CEO.</p>
        </div>
      </div>
    );
  }

  return <CEODashboard user={user} />;
}
