import { useState, useEffect } from "react";
import { AuthenticationSystem } from "@/components/auth/AuthenticationSystem";
import { useLocation } from "wouter";

interface AuthPageProps {
  onAuthSuccess: (user: any, token: string) => void;
}

export default function AuthPage({ onAuthSuccess }: AuthPageProps) {
  const [, setLocation] = useLocation();

  const handleAuthSuccess = (user: any, token: string) => {
    // Store token in localStorage
    localStorage.setItem("auth_token", token);
    localStorage.setItem("user", JSON.stringify(user));
    
    // Call the parent callback
    onAuthSuccess(user, token);
    
    // Redirect based on user role
    if (user.role === "ceo") {
      setLocation("/dashboard");
    } else {
      setLocation("/crm");
    }
  };

  return <AuthenticationSystem onAuthSuccess={handleAuthSuccess} />;
}
