import { WhatsAppCRM } from "@/components/crm/WhatsAppCRM";

interface CRMPageProps {
  user: any;
  token: string;
}

export default function CRMPage({ user, token }: CRMPageProps) {
  return <WhatsAppCRM user={user} token={token} />;
}
