import { ChatbotManagement } from "@/components/chatbot/ChatbotManagement";

interface ChatbotsPageProps {
  user: any;
}

export default function ChatbotsPage({ user }: ChatbotsPageProps) {
  return <ChatbotManagement user={user} />;
}
