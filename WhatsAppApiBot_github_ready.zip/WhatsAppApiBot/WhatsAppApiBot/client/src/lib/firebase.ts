import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  signInWithRedirect, 
  getRedirectResult, 
  GoogleAuthProvider,
  FacebookAuthProvider,
  signInAnonymously,
  type User
} from "firebase/auth";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyBibk3xPIJtyZxbvm_VUFwoR4THdf37wzw",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "security-maps-f2fa4.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "security-maps-f2fa4",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "security-maps-f2fa4.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "541489529860",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:541489529860:web:122681a0efad09ac0de151",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-HL8S7PRGZ0"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('email');
googleProvider.addScope('profile');

const facebookProvider = new FacebookAuthProvider();
facebookProvider.addScope('email');

export async function signInWithGoogle() {
  try {
    await signInWithRedirect(auth, googleProvider);
  } catch (error) {
    console.error("Google sign-in error:", error);
    throw error;
  }
}

export async function signInWithFacebook() {
  try {
    await signInWithRedirect(auth, facebookProvider);
  } catch (error) {
    console.error("Facebook sign-in error:", error);
    throw error;
  }
}

export async function signInAnonymous() {
  try {
    const result = await signInAnonymously(auth);
    return result.user;
  } catch (error) {
    console.error("Anonymous sign-in error:", error);
    throw error;
  }
}

export async function handleRedirectResult(): Promise<{ user: User; provider: string } | null> {
  try {
    const result = await getRedirectResult(auth);
    if (result) {
      const provider = result.providerId === 'google.com' ? 'google' : 'facebook';
      return { user: result.user, provider };
    }
    return null;
  } catch (error) {
    console.error("Redirect result error:", error);
    throw error;
  }
}

export { auth as firebaseAuth };
