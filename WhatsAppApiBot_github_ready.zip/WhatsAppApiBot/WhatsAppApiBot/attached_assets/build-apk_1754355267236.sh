#!/bin/bash

# FlowConnect APK Build Script
# This script builds the web app and generates an Android APK

echo "🚀 Building FlowConnect APK..."

# Step 1: Build the web application
echo "📦 Building web application..."
npm run build

# Step 2: Sync Capacitor files
echo "🔄 Syncing Capacitor files..."
npx cap sync android

# Step 3: Build APK using Gradle
echo "🏗️  Building APK with Gradle..."
cd android

# Make gradlew executable
chmod +x gradlew

# Build debug APK (faster for development)
./gradlew assembleDebug

# Build release APK (optimized for production)
./gradlew assembleRelease

echo "✅ APK build completed!"
echo "📱 Debug APK: android/app/build/outputs/apk/debug/FlowConnect-v1.0.0-1-debug.apk"
echo "📱 Release APK: android/app/build/outputs/apk/release/FlowConnect-v1.0.0-1-release.apk"

# Copy APKs to project root for easy access
cd ..
mkdir -p dist/apk
cp android/app/build/outputs/apk/debug/*.apk dist/apk/ 2>/dev/null || true
cp android/app/build/outputs/apk/release/*.apk dist/apk/ 2>/dev/null || true

echo "📁 APK files copied to dist/apk/ directory"