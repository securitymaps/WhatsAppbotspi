#!/bin/bash

# FlowConnect Complete APK Build Script
echo "🚀 Building FlowConnect APK with complete setup..."

# Set Java environment
export JAVA_HOME=/nix/store/zmj3m7wrgqf340vqd4v90w8dw371vhjg-openjdk-17.0.7+7/lib/openjdk
export PATH=$JAVA_HOME/bin:$PATH

# Build web application
echo "📦 Building web application..."
npm run build

# Sync Capacitor
echo "🔄 Syncing Capacitor files..."
npx cap sync android

# Create APK using Gradle directly
echo "🏗️  Building APK..."
cd android

# Use system Gradle instead of wrapper
gradle assembleDebug
gradle assembleRelease

echo "✅ APK build completed!"

# Check if APK files were created
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "📱 Debug APK: android/app/build/outputs/apk/debug/app-debug.apk"
fi

if [ -f "app/build/outputs/apk/release/app-release-unsigned.apk" ]; then
    echo "📱 Release APK: android/app/build/outputs/apk/release/app-release-unsigned.apk"
fi

# Copy APKs to project root
cd ..
mkdir -p dist/apk
cp android/app/build/outputs/apk/debug/*.apk dist/apk/ 2>/dev/null || true
cp android/app/build/outputs/apk/release/*.apk dist/apk/ 2>/dev/null || true

echo "📁 APK files ready in dist/apk/ directory"