import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with multi-authentication support
export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").unique(),
  username: text("username"),
  password: text("password"),
  phone: text("phone"),
  role: text("role", { enum: ["user", "admin", "ceo"] }).default("user"),
  authProvider: text("auth_provider", { enum: ["email", "google", "facebook", "phone", "anonymous"] }),
  firebaseUid: text("firebase_uid"),
  isVerified: boolean("is_verified").default(false),
  verificationToken: text("verification_token"),
  ceoToken: text("ceo_token"),
  isActive: boolean("is_active").default(true),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
});

// WhatsApp accounts linked to users
export const whatsappAccounts = pgTable("whatsapp_accounts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id),
  phoneNumberId: text("phone_number_id").notNull(),
  phoneNumber: text("phone_number").notNull(),
  accountId: text("account_id").notNull(),
  accessToken: text("access_token").notNull(),
  webhookVerifyToken: text("webhook_verify_token"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Contacts for the CRM
export const contacts = pgTable("contacts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id),
  whatsappAccountId: uuid("whatsapp_account_id").references(() => whatsappAccounts.id),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  company: text("company"),
  avatar: text("avatar"),
  lastMessageAt: timestamp("last_message_at"),
  isArchived: boolean("is_archived").default(false),
  tags: jsonb("tags").$type<string[]>(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Conversations between users and contacts
export const conversations = pgTable("conversations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id),
  contactId: uuid("contact_id").references(() => contacts.id),
  whatsappAccountId: uuid("whatsapp_account_id").references(() => whatsappAccounts.id),
  lastMessageAt: timestamp("last_message_at"),
  unreadCount: integer("unread_count").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Messages in conversations
export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: uuid("conversation_id").references(() => conversations.id),
  contactId: uuid("contact_id").references(() => contacts.id),
  whatsappMessageId: text("whatsapp_message_id"),
  direction: text("direction", { enum: ["inbound", "outbound"] }).notNull(),
  type: text("type", { enum: ["text", "image", "audio", "video", "document"] }).default("text"),
  content: text("content"),
  mediaUrl: text("media_url"),
  status: text("status", { enum: ["sent", "delivered", "read", "failed"] }).default("sent"),
  isFromBot: boolean("is_from_bot").default(false),
  timestamp: timestamp("timestamp").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chatbots configuration
export const chatbots = pgTable("chatbots", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id),
  whatsappAccountId: uuid("whatsapp_account_id").references(() => whatsappAccounts.id),
  name: text("name").notNull(),
  description: text("description"),
  template: text("template", { enum: ["corporate", "ecommerce", "healthcare", "education", "finance", "support"] }),
  isActive: boolean("is_active").default(true),
  config: jsonb("config"),
  triggers: jsonb("triggers").$type<string[]>(),
  responses: jsonb("responses"),
  analytics: jsonb("analytics"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Bot interactions for analytics
export const botInteractions = pgTable("bot_interactions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  chatbotId: uuid("chatbot_id").references(() => chatbots.id),
  contactId: uuid("contact_id").references(() => contacts.id),
  messageId: uuid("message_id").references(() => messages.id),
  trigger: text("trigger"),
  response: text("response"),
  wasEscalated: boolean("was_escalated").default(false),
  satisfactionScore: integer("satisfaction_score"),
  responseTime: integer("response_time_ms"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Webhook events log
export const webhookEvents = pgTable("webhook_events", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  whatsappAccountId: uuid("whatsapp_account_id").references(() => whatsappAccounts.id),
  eventType: text("event_type").notNull(),
  payload: jsonb("payload"),
  processed: boolean("processed").default(false),
  error: text("error"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  whatsappAccounts: many(whatsappAccounts),
  contacts: many(contacts),
  conversations: many(conversations),
  chatbots: many(chatbots),
}));

export const whatsappAccountsRelations = relations(whatsappAccounts, ({ one, many }) => ({
  user: one(users, { fields: [whatsappAccounts.userId], references: [users.id] }),
  contacts: many(contacts),
  conversations: many(conversations),
  chatbots: many(chatbots),
  webhookEvents: many(webhookEvents),
}));

export const contactsRelations = relations(contacts, ({ one, many }) => ({
  user: one(users, { fields: [contacts.userId], references: [users.id] }),
  whatsappAccount: one(whatsappAccounts, { fields: [contacts.whatsappAccountId], references: [whatsappAccounts.id] }),
  conversations: many(conversations),
  messages: many(messages),
  botInteractions: many(botInteractions),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  user: one(users, { fields: [conversations.userId], references: [users.id] }),
  contact: one(contacts, { fields: [conversations.contactId], references: [contacts.id] }),
  whatsappAccount: one(whatsappAccounts, { fields: [conversations.whatsappAccountId], references: [whatsappAccounts.id] }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, { fields: [messages.conversationId], references: [conversations.id] }),
  contact: one(contacts, { fields: [messages.contactId], references: [contacts.id] }),
}));

export const chatbotsRelations = relations(chatbots, ({ one, many }) => ({
  user: one(users, { fields: [chatbots.userId], references: [users.id] }),
  whatsappAccount: one(whatsappAccounts, { fields: [chatbots.whatsappAccountId], references: [whatsappAccounts.id] }),
  interactions: many(botInteractions),
}));

export const botInteractionsRelations = relations(botInteractions, ({ one }) => ({
  chatbot: one(chatbots, { fields: [botInteractions.chatbotId], references: [chatbots.id] }),
  contact: one(contacts, { fields: [botInteractions.contactId], references: [contacts.id] }),
  message: one(messages, { fields: [botInteractions.messageId], references: [messages.id] }),
}));

export const webhookEventsRelations = relations(webhookEvents, ({ one }) => ({
  whatsappAccount: one(whatsappAccounts, { fields: [webhookEvents.whatsappAccountId], references: [whatsappAccounts.id] }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const insertWhatsappAccountSchema = createInsertSchema(whatsappAccounts).omit({
  id: true,
  createdAt: true,
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
  lastMessageAt: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  lastMessageAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  timestamp: true,
});

export const insertChatbotSchema = createInsertSchema(chatbots).omit({
  id: true,
  createdAt: true,
});

export const insertBotInteractionSchema = createInsertSchema(botInteractions).omit({
  id: true,
  timestamp: true,
});

export const insertWebhookEventSchema = createInsertSchema(webhookEvents).omit({
  id: true,
  timestamp: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWhatsappAccount = z.infer<typeof insertWhatsappAccountSchema>;
export type WhatsappAccount = typeof whatsappAccounts.$inferSelect;

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type InsertChatbot = z.infer<typeof insertChatbotSchema>;
export type Chatbot = typeof chatbots.$inferSelect;

export type InsertBotInteraction = z.infer<typeof insertBotInteractionSchema>;
export type BotInteraction = typeof botInteractions.$inferSelect;

export type InsertWebhookEvent = z.infer<typeof insertWebhookEventSchema>;
export type WebhookEvent = typeof webhookEvents.$inferSelect;
